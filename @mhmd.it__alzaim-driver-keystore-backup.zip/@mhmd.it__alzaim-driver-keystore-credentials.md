# Android Keystore Credentials

These credentials are used in conjunction with your Android keystore file to sign your app for distribution. 

## Credential Values

- Android keystore password: 25de951f5af759dcaee26aa45910671c
- Android key alias: 2d79d19e2ab5fc48de17df9cf3247387
- Android key password: ad2a6436a274787511045909edb1487a
      